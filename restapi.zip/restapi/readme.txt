
Database Architecture Overview
==================================

+---------------+          +----------------+          +--------------+           +-------------+
|   Category    |          |  Subcategory   |          |   Question   |           |    Answer    |
+---------------+          +----------------+          +--------------+           +-------------+
| id (PK)       | 1 -----o | id (PK)        | 1 -----o | id (PK)       | o ------> | id (PK)      |
| name          |          | name           |          | text          |           | answer       |
+---------------+          | category_id (FK) |        | subcategory_id (FK)|      | question_id (FK) |
                           +----------------+          +--------------+           | user_id (FK) |
                                                                                   +-------------+

                                          |
                                          |
                                          |
                                      +---------+
                                      |  User   |
                                      +---------+
                                      | id (PK) |
                                      | username|
                                      +---------+

Base URL
http://localhost:8000/

Endpoints
Method    Endpoint                                           Description
GET       /admin/                                           Admin interface for managing application data.
POST      /signup/                                          Creates a new user account.
POST      /login/                                           Logs a user in and redirects to the specified URL upon successful authentication.
GET       /logout/                                          Logs a user out and redirects to the login page.
GET       /categories/                                      Retrieves a list of all categories.
POST      /categories/                                      Creates a new category.
GET       /categories/<int:pk>/                           Retrieves details of a specific category identified by its primary key (pk).
PUT       /categories/<int:pk>/                           Updates a specific category identified by its primary key (pk).
DELETE    /categories/<int:pk>/                           Deletes a specific category identified by its primary key (pk).
POST      /subcategories/                                   Creates a new subcategory.
POST      /subcategories/<int:subcategory_id>/questions/  Creates a new question under the specified subcategory identified by its ID.
GET       /discovery-report/                               Displays the discovery report form.
GET       /dummydata/<int:subcategory_id>/                Loads dummy data for the specified subcategory, primarily for development or testing purposes.
DELETE    /wastesubcategories/<int:subcategory_id>/       Deletes the specified subcategory identified by its ID.


Explanation of Relationships:
Category and Subcategory:

A Category can have multiple Subcategories, so the relationship between them is a one-to-many (1 -----o).
Subcategory and Question:

A Subcategory can have multiple Questions, so it's a one-to-many relationship (1 -----o).
Question and Answer:

A Question can have multiple Answers from different users, so it's also a one-to-many relationship (1 -----o).
User and Answer:

A User can submit multiple Answers, forming another one-to-many relationship between User and Answer.
Field Summary:
Category:

id (Primary Key)
name (Category name)
Subcategory:

id (Primary Key)
name (Subcategory name)
category_id (Foreign Key referencing Category)
Question:

id (Primary Key)
text (Question text)
subcategory_id (Foreign Key referencing Subcategory)
Answer:

id (Primary Key)
answer (Yes/No)
question_id (Foreign Key referencing Question)
user_id (Foreign Key referencing User)
User (from Django’s User model):

id (Primary Key)
username (User's username)
This diagram represents the relationships between the Category, Subcategory, Question, Answer, and User models in your Django project.

Let me know if you'd like further modifications or details!





API Documentation
1. User Signup
Endpoint: /signup/
Description: Registers a new user.
Method: POST
Parameters:
username: (string) Username of the user.
email: (string) Email of the user.
password: (string) Password for the account.
Response: A success or failure message indicating whether the user was created.


2. User Login
Endpoint: /login/
Description: Authenticates an existing user.
Method: POST
Parameters:
username: (string) Username of the user.
password: (string) Password for the account.
Response: Redirects to the next page or returns an error if credentials are invalid.


3. User Logout
Endpoint: /logout/
Description: Logs out the current authenticated user.
Method: GET
Response: Redirects the user to the login page.


4. List/Create Categories
Endpoint: /categories/
Description:
GET: Lists all categories.
POST: Creates a new category.
Methods: GET, POST
Request Body (POST):
Post Response:-


    {"id":55,"name":"testm1","category":10} 

name: (string) Name of the category.
Sample Response (GET):
json
Get Response:--
            [
                {
                    "id": 1,
                    "name": "Connectivity",
                    "subcategories": [
                        {
                            "id": 1,
                            "name": "Internet Connection",
                            "questions": [
                                {
                                    "id": 1,
                                    "text": "Provider is good"
                                },
                                {
                                    "id": 2,
                                    "text": "Service is reliable"
                                },
                                {
                                    "id": 3,
                                    "text": "Speed is sufficient"
                                },
                                {
                                    "id": 4,
                                    "text": "Actual speed is in range of subscribed speed"
                                }
                            ]
                        }
                        ....
                    ]
                }
            ]



5. Category Detail
Endpoint: /categories/<int:pk>/
Description:
GET: Retrieves details of a specific category.
PUT: Updates the specified category.
DELETE: Deletes the specified category.
Methods: GET
Path Parameter:
pk: (int) The primary key of the category.
Sample Response (GET):
json

Response:-
            [
                {
                    "id": 1,
                    "name": "Connectivity",
                    "subcategories": [
                        {
                            "id": 1,
                            "name": "Internet Connection",
                            "questions": [
                                {
                                    "id": 1,
                                    "text": "Provider is good"
                                },
                                {
                                    "id": 2,
                                    "text": "Service is reliable"
                                },
                                {
                                    "id": 3,
                                    "text": "Speed is sufficient"
                                },
                                {
                                    "id": 4,
                                    "text": "Actual speed is in range of subscribed speed"
                                }
                            ]
                        }
                        ....
                    ]
                }
            ]
Request Body (PUT):
json
Copy code
{
  "name": "Updated Category Name"
}
Response (DELETE): 204 No Content


6. Create Subcategory
Endpoint: /subcategories/
Description: Creates a new subcategory.
Method: POST
Request Body:
category: (int) ID of the category this subcategory belongs to.
name: (string) Name of the subcategory.
Sample Response:
json
Copy code
{
  "id": 5,
  "category": 1,
  "name": "New Subcategory"
}


7. Create Questions for a Subcategory
Endpoint: /subcategories/<int:subcategory_id>/questions/
Description: Adds a question to a specific subcategory.
Method: POST
Path Parameter:
subcategory_id: (int) The ID of the subcategory to which the question belongs.
Request Body:
text: (string) The question text.
Sample Response:
json
Copy code
Response:-

    {"id":54,"questions":[{"id":119,"text":"demo"}]}

8. Discovery Report Form
Endpoint: /discovery-report/
Description: Displays a form with categories, subcategories, and questions. Allows users to submit answers.
Method: GET, POST


Response:
On GET: The form with categories, subcategories, and questions.
On POST: Saves the user's answers to the questions and redirects to the report page.
Status Codes
200 OK: The request was successful.
201 Created: A resource was successfully created.
204 No Content: The resource was successfully deleted.
400 Bad Request: The request was invalid or missing required fields.
404 Not Found: The requested resource could not be found.
500 Internal Server Error: An error occurred on the server.

Latency is low:
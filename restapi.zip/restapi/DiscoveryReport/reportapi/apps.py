from django.apps import AppConfig


class ReportapiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'reportapi'

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from .models import Category,Subcategory,Question,Answer
from .serializers import CategorySerializer,SubCategorySerializer,QuestionSerializer,SubcategoryWithQuestionSerializer,SubcatwithQuestWithoutCatSerializer
from django.http import JsonResponse
import json
import os
from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from rest_framework import status
from rest_framework.decorators import api_view


class CategoryAPIView(APIView):

    def get(self, request, format=None):
        categories = Category.objects.all()
        serializer = CategorySerializer(categories, many=True)
        return Response(serializer.data)

    def post(self, request, format=None):
        serializer = CategorySerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class CategoryDetailAPIView(APIView):

    def get_object(self, pk):
        try:
            return Category.objects.get(pk=pk)
        except Category.DoesNotExist:
            return None

    def get(self, request, pk, format=None):
        category = self.get_object(pk)
        if category is None:
            return Response(status=status.HTTP_404_NOT_FOUND)
        serializer = CategorySerializer(category)
        return Response(serializer.data)

    def put(self, request, pk, format=None):
        category = self.get_object(pk)
        if category is None:
            return Response(status=status.HTTP_404_NOT_FOUND)
        serializer = CategorySerializer(category, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk, format=None):
        category = self.get_object(pk)
        if category is None:
            return Response(status=status.HTTP_404_NOT_FOUND)
        category.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

class SubCategoryCreateView(APIView):
    def post(self, request):
        serializer = SubCategorySerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



class QuestionCreateView(APIView):
    def post(self, request, subcategory_id):
        try:
            subcategory = Subcategory.objects.get(id=subcategory_id)
        except Subcategory.DoesNotExist:
            return Response({'error': 'Subcategory not found'}, status=status.HTTP_404_NOT_FOUND)

        data = request.data
        data['subcategory'] = subcategory.id  # Associate the question with the correct subcategory

        serializer = SubcatwithQuestWithoutCatSerializer(data=data, context={'subcategory': subcategory})
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



@login_required
def discovery_report_view(request):
    categories = Category.objects.prefetch_related('subcategories__questions')

    if request.method == 'POST':
        print("POST Data: bhuvan", request.POST)
        # Loop through questions and store answers
        for question in Question.objects.all():
            answer_value = request.POST.get(f'answer_{question.id}')
            if answer_value:  # Ensure answer exists
                Answer.objects.create(
                    user=request.user,
                    question=question,
                    answer=answer_value
                )

        # After saving, redirect the user to a success page or the same form
        return redirect('discovery_report')  # or to a success page
    answers=Answer.objects.all()
    print("bhuvan kumar",answers)
    context = {'categories': categories}
    return render(request, 'discovery_report.html', context)



def signup_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)  # Automatically log in the user after signup
            return redirect('discovery_report')  # Redirect to the discovery report
    else:
        form = UserCreationForm()
    
    return render(request, 'signup.html', {'form': form})



# Developing purpose insert data from json file

class DummydataCreateView(APIView):
    def get(self, request):
        # Load JSON data from file
        try:
            # Get the path to the JSON file in the same directory as this file
            file_path = os.path.join(os.path.dirname(__file__), 'db.json')
            
            with open(file_path) as json_file:
                data = json.load(json_file)

            inserted_count = 0  # Track the number of inserted records

            # Create categories, subcategories, and questions
            for category_name, subcategories in data.items():
                category, created = Category.objects.get_or_create(name=category_name)
                
                for subcategory_name, questions in subcategories.items():
                    subcategory, created = Subcategory.objects.get_or_create(name=subcategory_name, category=category)
                    
                    for question_text in questions:
                        question, created = Question.objects.get_or_create(text=question_text, subcategory=subcategory)
                        if created:  # Only increment if a new question was created
                            inserted_count += 1

            return JsonResponse({
                "message": f"Data has been successfully inserted into the database. {inserted_count} questions added."
            }, status=201)

        except FileNotFoundError:
            return JsonResponse({"error": "The specified JSON file was not found."}, status=404)
        except json.JSONDecodeError:
            return JsonResponse({"error": "Failed to decode JSON."}, status=400)
        except Exception as e:
            return JsonResponse({"error": str(e)}, status=500)

class SubcategoryDeleteView(APIView):
    def delete(self, request, subcategory_id):
        try:
            subcategory = Subcategory.objects.get(id=subcategory_id)
            subcategory.delete()
            return Response(status=status.HTTP_204_NO_CONTENT)  # Successfully deleted
        except Subcategory.DoesNotExist:
            return Response({'error': 'Subcategory not found'}, status=status.HTTP_404_NOT_FOUND)

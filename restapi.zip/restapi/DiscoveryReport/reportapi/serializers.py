from rest_framework import serializers
from .models import Category, Subcategory, Question

class QuestionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Question
        fields = ['id', 'text']

class SubcategoryWithQuestionSerializer(serializers.ModelSerializer):
    questions = QuestionSerializer(many=True)

    class Meta:
        model = Subcategory
        fields = ['id', 'name', 'questions']



class CategorySerializer(serializers.ModelSerializer):
    subcategories = SubcategoryWithQuestionSerializer(many=True, read_only=True)

    class Meta:
        model = Category
        fields = ['id', 'name', 'subcategories']


class SubCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Subcategory
        fields = ['id', 'name', 'category']

class SubcatwithQuestWithoutCatSerializer(serializers.ModelSerializer):
    questions = QuestionSerializer(many=True)

    class Meta:
        model = Subcategory
        fields = ['id', 'questions']
    
    def create(self, validated_data):
        questions_data = validated_data.pop('questions', [])
        subcategory = self.context['subcategory']

        for question_data in questions_data:
            Question.objects.create(subcategory=subcategory, **question_data)

        return subcategory

"""
URL configuration for DiscoveryReport project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.contrib.auth import views as auth_views
from reportapi.views import CategoryAPIView, CategoryDetailAPIView,DummydataCreateView,SubCategoryCreateView,QuestionCreateView,SubcategoryDeleteView,discovery_report_view,signup_view
urlpatterns = [
    path('admin/', admin.site.urls),
    path('signup/', signup_view, name='signup'),
    path('login/', auth_views.LoginView.as_view(template_name='login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(next_page='login'), name='logout'),
    path('categories/', CategoryAPIView.as_view(), name='category-list-create'),
    path('categories/<int:pk>/', CategoryDetailAPIView.as_view(), name='category-detail'),
    path('subcategories/', SubCategoryCreateView.as_view(), name='subcategory-create'),
    path('subcategories/<int:subcategory_id>/questions/', QuestionCreateView.as_view(), name='question-create'),
    path('discovery-report/', discovery_report_view, name='discovery_report'),
    path('dummydata/<int:subcategory_id>/', DummydataCreateView.as_view(), name='dummydata'),
    path('wastesubcategories/<int:subcategory_id>/', SubcategoryDeleteView.as_view(), name='subcategory-delete'),

]

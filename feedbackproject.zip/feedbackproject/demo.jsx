import React, { useState, useEffect } from "react";
import { Modal, Button, Form, Accordion } from "react-bootstrap";
import 'bootstrap/dist/css/bootstrap.min.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPlus } from '@fortawesome/free-solid-svg-icons';
import './DiscoveryReport.css';

const DiscoveryReport = () => {
  const [connectivityData, setConnectivityData] = useState([]);
  const [newCategory, setNewCategory] = useState("");
  const [newSubCategory, setNewSubCategory] = useState("");
  const [newQuestion, setNewQuestion] = useState("");
  const [currentCategoryIndex, setCurrentCategoryIndex] = useState(null);
  const [currentSubCategoryIndex, setCurrentSubCategoryIndex] = useState(null);
  const [showCategoryModal, setShowCategoryModal] = useState(false);
  const [showSubCategoryModal, setShowSubCategoryModal] = useState(false);
  const [showQuestionModal, setShowQuestionModal] = useState(false);
  const [activeKey, setActiveKey] = useState("0"); // To manage active Accordion key

  const fetchCategories = async () => {
    try {
      const response = await fetch("http://127.0.0.1:8000/categories/");
      const data = await response.json();
      setConnectivityData(data);
    } catch (error) {
      console.error("Error fetching categories:", error);
    }
  };

  useEffect(() => {
    fetchCategories();
  }, []);

  const addCategory = () => {
    if (newCategory.trim()) {
      setConnectivityData(prev => [
        ...prev,
        { name: newCategory, subcategories: [] }
      ]);
      setNewCategory("");
      setShowCategoryModal(false);
    }
  };

  const addSubCategory = async () => {
    if (newSubCategory.trim() !== "" && currentCategoryIndex !== null) {
        const updatedCategories = [...connectivityData];
        const categoryId = updatedCategories[currentCategoryIndex].id;

        const newSubCategoryData = {
            name: newSubCategory,
            category: categoryId
        };

        try {
            const response = await fetch(`http://localhost:8000/subcategories/`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(newSubCategoryData)
            });

            if (!response.ok) {
                throw new Error('Failed to add subcategory');
            }

            const newSubCategoryResponse = await response.json();
            updatedCategories[currentCategoryIndex].subcategories.push({
                ...newSubCategoryResponse,
                questions: []
            });

            setConnectivityData(updatedCategories);
            setNewSubCategory("");
            setShowSubCategoryModal(false);
            
        } catch (error) {
            console.error("Error adding subcategory:", error);
        }
    }
};

const addQuestion = async () => {
    if (newQuestion.trim() !== "" && currentCategoryIndex !== null && currentSubCategoryIndex !== null) {
        const updatedCategories = [...connectivityData];
        const newQuestionData = { text: newQuestion };

        updatedCategories[currentCategoryIndex].subcategories[currentSubCategoryIndex].questions.push(newQuestionData);
        setConnectivityData(updatedCategories);
        setNewQuestion("");
        setShowQuestionModal(false);

        const subcategoryId = updatedCategories[currentCategoryIndex].subcategories[currentSubCategoryIndex].id;

        try {
            const response = await fetch(`http://localhost:8000/subcategories/${subcategoryId}/questions/`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    questions: [newQuestionData]
                })
            });

            if (!response.ok) {
                throw new Error('Failed to add question');
            }

        } catch (error) {
            console.error("Error adding question:", error);
        }
    }
};

  return (
    <div className="discovery-report-container">
      <h2>Discovery Report Input Template</h2>

      {/* Parent div for Accordion and Add button */}
      <div className="accordion-wrapper">
        {/* Accordion component */}
        <Accordion activeKey={activeKey} onSelect={(eventKey) => setActiveKey(eventKey)}>
          {connectivityData.map((category, categoryIndex) => (
            <Accordion.Item eventKey={categoryIndex.toString()} key={categoryIndex}>
              <Accordion.Header>
                {category.name}
                <Button
                  variant="success"
                  className="btn-sm ms-2"
                  onClick={() => { 
                    setCurrentCategoryIndex(categoryIndex); 
                    setShowSubCategoryModal(true); 
                  }}
                >
                  <FontAwesomeIcon icon={faPlus} />
                </Button>
              </Accordion.Header>
              <Accordion.Body>
                <Accordion>
                  {category.subcategories.map((subCat, subIndex) => (
                    <Accordion.Item eventKey={subIndex.toString()} key={subIndex}>
                      <Accordion.Header>
                        {subCat.name}
                        <Button
                          variant="success"
                          className="btn-sm ms-2"
                          onClick={() => { 
                            setCurrentCategoryIndex(categoryIndex); 
                            setCurrentSubCategoryIndex(subIndex); 
                            setShowQuestionModal(true); 
                          }}
                        >
                          <FontAwesomeIcon icon={faPlus} />
                        </Button>
                      </Accordion.Header>
                      <Accordion.Body>
                        {subCat.questions.length === 0 ? (
                          <p className="no-questions">No questions added yet.</p>
                        ) : (
                          <ol>
                            {subCat.questions.map((question, questionIndex) => (
                              <li key={questionIndex}>
                                <div className="form-check d-flex align-items-center mt-2">
                                  <label className="form-check-label">{question.text}</label>
                                </div>
                              </li>
                            ))}
                          </ol>
                        )}
                      </Accordion.Body>
                    </Accordion.Item>
                  ))}
                </Accordion>
              </Accordion.Body>
            </Accordion.Item>
          ))}
        </Accordion>

        {/* Button to add new category */}
        <Button variant="primary" className="add-category-button" onClick={() => setShowCategoryModal(true)}>
          Add Category
        </Button>
      </div>

      {/* Add Category Modal */}
      <Modal show={showCategoryModal} onHide={() => setShowCategoryModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Add Category</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group controlId="categoryName">
              <Form.Label>Category Name</Form.Label>
              <Form.Control
                type="text"
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value)}
                required
              />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowCategoryModal(false)}>
            Close
          </Button>
          <Button variant="primary" onClick={addCategory}>
            Add
          </Button>
        </Modal.Footer>
      </Modal>

      {/* Add SubCategory Modal */}
      <Modal show={showSubCategoryModal} onHide={() => setShowSubCategoryModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Add Subcategory</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group controlId="subCategoryName">
              <Form.Label>Subcategory Name</Form.Label>
              <Form.Control
                type="text"
                value={newSubCategory}
                onChange={(e) => setNewSubCategory(e.target.value)}
                required
              />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowSubCategoryModal(false)}>
            Close
          </Button>
          <Button variant="primary" onClick={addSubCategory}>
            Add
          </Button>
        </Modal.Footer>
      </Modal>

      {/* Add Question Modal */}
      <Modal show={showQuestionModal} onHide={() => setShowQuestionModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Add Question</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group controlId="questionText">
              <Form.Label>Question</Form.Label>
              <Form.Control
                type="text"
                value={newQuestion}
                onChange={(e) => setNewQuestion(e.target.value)}
                required
              />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowQuestionModal(false)}>
            Close
          </Button>
          <Button variant="primary" onClick={addQuestion}>
            Add
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default DiscoveryReport;

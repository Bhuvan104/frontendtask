import React, { useState } from "react";
import { Modal, Button, Form } from "react-bootstrap"; // Assuming you're using React Bootstrap

const QuestionModal = ({ show, onHide, addQuestion, currentCategory }) => {
  const [questionText, setQuestionText] = useState("");

  const handleSubmit = (event) => {
    event.preventDefault();
    if (questionText.trim()) {
      addQuestion(questionText); // Call the addQuestion function passed from the parent component
      setQuestionText(""); // Clear the input after submission
      onHide(); // Close the modal
    }
  };

  return (
    <Modal show={show} onHide={onHide}>
      <Modal.Header closeButton>
        <Modal.Title>Add Question to {currentCategory}</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form onSubmit={handleSubmit}>
          <Form.Group controlId="questionText">
            <Form.Label>Question</Form.Label>
            <Form.Control
              type="text"
              placeholder="Enter your question"
              value={questionText}
              onChange={(e) => setQuestionText(e.target.value)}
              required
            />
          </Form.Group>
          <Button variant="primary" type="submit">
            Add Question
          </Button>
        </Form>
      </Modal.Body>
    </Modal>
  );
};

export default QuestionModal;
